<footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
        <div class="row">
            <nav class="footer-nav">
                
            </nav>
            <div class="credits ml-auto">
                <span class="copyright">
                    ©
                    <script>
                        document.write(new Date().getFullYear())
                    </script><?php echo e(__(', made with ')); ?><i class="fa fa-heart heart"></i><?php echo e(__(' by ')); ?><a class="<?php if(Auth::guest()): ?> text-white <?php endif; ?>" href="https://www.dextratechnologies.com" target="_blank"><?php echo e(__('Dextra Technologies')); ?></a>
                </span>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\waterapp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>