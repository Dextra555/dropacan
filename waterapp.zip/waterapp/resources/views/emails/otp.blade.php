<p>Your OTP code is: <strong>{{ $otpCode }}</strong></p>
<p>This code will expire in 10 minutes.</p>
<p>Thank you for using our application!</p>
